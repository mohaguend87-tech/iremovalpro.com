<!DOCTYPE html>
<html lang="en" >

<head>

  <meta charset="UTF-8">
  


  <title>Premium Edition Registration | iRemoval PRO</title>
  <link rel='shortcut icon' href='/icone.ico' type='image/x-icon' />
  
  
  
  
<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
html {
  font-size: 15px;
}
body {
  background: #f7f7ff;
  font-family: "Montserrat", sans-serif;
  width: 80%;
  max-width: 1440px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  overflow-x: hidden;
}
header {
  color: hsla(177, 89%, 25%);
  margin: 3.3rem 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.toggle {
  margin-top: 2rem;
  color: hsl(234, 14%, 74%);
  display: flex;
  align-items: center;
}
.toggle-btn {
  margin: 0 1rem;
}
.checkbox {
  display: none;
}

.sub {
  background: linear-gradient(
    135deg,
    rgba(9, 136, 125, 1) 0%,
    rgba(7, 122, 117, 1) 100%
  );
  display: flex;
  justify-content: flex-start;
  align-items: center;
  /* height: 25px;
  width: 50px; */
  height: 1.6rem;
  width: 3.3rem;
  border-radius: 1.6rem;
  padding: 0.3rem;
}
.circle {
  background-color: #fff;
  height: 1.4rem;
  width: 1.4rem;
  border-radius: 50%;
}
.checkbox:checked + .sub {
  justify-content: flex-end;
}

.cards {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.card {
  background: #fff;
  color: hsl(233, 13%, 49%);
  border-radius: 0.8rem;
}

.cards .card.active {
  background: linear-gradient(
    135deg,
    rgba(9, 136, 125, 1) 0%,
    rgba(7, 122, 117, 1) 100%
  );
  color: #fff;
  display: flex;
  align-items: center;
  transform: scale(1.1);
  z-index: 1;
}
ul {
  margin: 2.6rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
}
ul li {
  list-style-type: none;
  display: flex;
  justify-content: center;
  width: 100%;
  padding: 1rem 0;
}
ul li.price {
  font-size: 3rem;
  color: hsl(232, 13%, 33%);
  padding-bottom: 2rem;
}
.shadow {
  box-shadow: -5px 5px 15px 1px rgba(0, 0, 0, 0.1);
}

.card.active .price {
  color: #fff;
}

.btn {
  margin-top: 1rem;
  height: 2.6rem;
  width: 13.3rem;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 4px;
  background: linear-gradient(
    135deg,
    rgba(9, 136, 125, 1) 0%,
    rgba(7, 122, 117, 1) 100%
  );
  color: #fff;
  outline: none;
  border: 0;
  font-weight: bold;
}
.active-btn {
  background: #fff;
  color: hsl(177, 89%, 25%);
}
.bottom-bar {
  border-bottom: 2px solid hsla(240, 8%, 85%, 0.582);
}
.card.active .bottom-bar {
  border-bottom: 2px solid hsla(240, 8%, 85%, 0.253);
}
.pack {
  font-size: 1.1rem;
}

@media (max-width: 280px) {
  ul {
    margin: 1rem;
  }
  h1 {
    font-size: 1.2rem;
  }
  .toggle {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    height: 80px;
  }
  .cards {
    margin: 0;
    display: flex;
    flex-direction: column;
  }

  .card {
    transform: scale(0.8);
    margin-bottom: 1rem;
  }
  .cards .card.active {
    transform: scale(0.8);
  }
}

@media (min-width: 280px) and (max-width: 320px) {
  ul {
    margin: 20px;
  }
  .cards {
    display: flex;
    flex-direction: column;
  }
  .card {
    margin-bottom: 1rem;
  }
  .cards .card.active {
    transform: scale(1);
  }
}

@media (min-width: 320px) and (max-width: 414px) {
  .cards {
    display: flex;
    flex-direction: column;
  }
  .card {
    margin-bottom: 1rem;
  }
  .cards .card.active {
    transform: scale(1);
  }
}
@media (min-width: 414px) and (max-width: 768px) {
  .card {
    margin-bottom: 1rem;
    margin-right: 1rem;
  }
  .cards .card.active {
    transform: scale(1);
  }
}
@media (min-width: 768px) and (max-width: 1046px) {
  .cards {
    display: flex;
  }
  .card {
    margin-bottom: 1rem;
    margin-right: 1rem;
  }
  .cards .card.active {
    transform: scale(1);
  }
}
@import url("https://fonts.googleapis.com/css?family=Open+Sans:600");
@-webkit-keyframes short-press {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(0.9);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes short-press {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(0.9);
  }
  100% {
    transform: scale(1);
  }
}
html,
body {
  width: 100%;
  height: 100%;
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 16px;
  background: #f9f9f9;
}

.hide {
  display: none;
}

.submit-button {
  display: block;
  font-family: "Open Sans", Helvetica, Arial, sans-serif;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.75em;
  letter-spacing: 1px;
  height: 38px;
  width: 120px;
  line-height: 38px;
  overflow: hidden;
  background: #243328;
  border-radius: 3px;
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
  border: 0;
  cursor: pointer;
  transition: all 0.3s ease;
}
.submit-button:hover, .submit-button:focus {
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}
.submit-button.animated {
  -webkit-animation: 0.75s short-press cubic-bezier(0.77, 0, 0.175, 1) forwards;
          animation: 0.75s short-press cubic-bezier(0.77, 0, 0.175, 1) forwards;
}
.submit-button > span {
  display: block;
  color: white;
  text-align: center;
}
.submit-button > span.pre-state-msg {
  transition: all 0.7s cubic-bezier(0.77, 0, 0.175, 1);
  transition-delay: 0.75s;
}
.submit-button.state-1 .pre-state-msg {
  margin-top: -38px;
}
.submit-button.state-2 .pre-state-msg {
  margin-top: -76px;
}
.form__group {
  position: relative;
  padding: 15px 0 0;
  margin-top: 10px;
  width: 50%;
}

.form__field {
  font-family: inherit;
  width: 60%;
  border: 0;
  border-bottom: 2px solid #000;
  outline: 0;
  font-size: 1.3rem;
  color: #000;
  padding: 7px 0;
  background: transparent;
  transition: border-color 0.2s;
}
.form__field::placeholder {
  color: black;
  opacity: 50%;
}
.form__field:placeholder-shown ~ .form__label {
  font-size: 1.3rem;
  cursor: text;
  top: 20px;
}

.form__label {
  position: absolute;
  top: 0;
  display: block;
  transition: 0.2s;
  font-size: 1rem;
  color: #9b9b9b;
}

.form__field:focus {
  padding-bottom: 6px;
  font-weight: 700;
  border-width: 3px;
  border-image: linear-gradient(to right, #11998e, #38ef7d);
  border-image-slice: 1;
}
.form__field:focus ~ .form__label {
  position: absolute;
  top: 0;
  display: block;
  transition: 0.2s;
  font-size: 1rem;
  color: #11998e;
  font-weight: 700;
}

/* reset input */
.form__field:required, .form__field:invalid {
  box-shadow: none;
}
a:hover {
 cursor:pointer;
}

</style>

  <script>
  window.console = window.console || function(t) {};
</script>

  
  
  <script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>

<script language="JavaScript">
  window.onload = function() {
    document.addEventListener("contextmenu", function(e){
      e.preventDefault();
    }, false);
    document.addEventListener("keydown", function(e) {
    //document.onkeydown = function(e) {
      // "I" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
        disabledEvent(e);
      }
      // "J" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
        disabledEvent(e);
      }
      // "S" key + macOS
      if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
        disabledEvent(e);
      }
      // "U" key
      if (e.ctrlKey && e.keyCode == 85) {
        disabledEvent(e);
      }
      // "F12" key
      if (event.keyCode == 123) {
        disabledEvent(e);
      }
    }, false);
    function disabledEvent(e){
      if (e.stopPropagation){
        e.stopPropagation();
      } else if (window.event){
        window.event.cancelBubble = true;
      }
      e.preventDefault();
      return false;
    }
  };
</script>

</head>

<body translate="no" >
  <link rel="icon" type="image/png" sizes="32x32" href="./images/favicon-32x32.png" />
<link rel="preconnect" href="https://fonts.gstatic.com" />
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet" />

<title>Pricing component</title>
</head>

<body>
  <header>
    <h1>iRemovalPRO Services</h1>
  </header>
  <div class="cards">
    
    <div class="card active">
      <ul>
        <li class="pack">A12+ Premium Edition</li>
        <li id="professional" class="price bottom-bar">&dollar;53~&dollar;118</li>
        <li class="bottom-bar">From XS to 16 Pro Max - No Signal Untethered</li>
        <li class="bottom-bar">iOS 18.3 and UP, batch process(not instant!)</li>
        <form method="post" action="checkoutv4.php" id="ismForm">
        <br>
            &nbsp;<input id="serial_number" name="serial_number" class="form__field" type="text" minlength="10" maxlength="12" placeholder="Serial Number..." pattern="[A-Za-z0-9]{10,12}"  required="">
                            <input type="hidden" name="csrf_token" value="44b104a168abf51f6b91a2ccd53dcd2cfd24d311455a299517d60c20f4dc3f24">
                            <input type="checkbox" id="confirm" name="confirmGSM" value="I CONFIRM IM AGREE" required="">
                            <a href="/terms-of-agreement" style="color:black;font-size:18px;"><label style="color:black;font-size:18px;cursor:pointer" for="confirmGSM"> I agree</label></a>
                            <br><br><center><button name="submit" class="submit-button state-0"><span class="pre-state-msg">Purchase</span><span class="current-state-msg hide">Redirecting...</span></button></center>
        </form>
      </ul>
    </div>
  </div>
  <br>
  <br>
  
</form>
</body>


</body>

</html>